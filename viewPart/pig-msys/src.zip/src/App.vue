<template>
  <div id="app">
    <router-view />
  </div>
</template>

<style lang="scss">
body {
  font-family: "微软雅黑";
  margin: 0 auto;
}
</style>
